package com.example.projecte2_mobiles

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
